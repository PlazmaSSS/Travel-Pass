package com.example.ecotrack

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class AddHabitActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_habit)

        // Темные иконки статус-бара
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true

        val btnSave = findViewById<Button>(R.id.btnSave)
        val etTitle = findViewById<EditText>(R.id.etHabitTitle)
        val etDescription = findViewById<EditText>(R.id.etHabitDescription)

        btnSave.setOnClickListener {
            val title = etTitle.text.toString()
            val description = etDescription.text.toString()

            if (title.isNotEmpty()) {
                val newHabit = Habit(title = title, description = description)

                lifecycleScope.launch {
                    val db = AppDatabase.getDatabase(this@AddHabitActivity)

                    db.habitDao().insert(newHabit)

                    Toast.makeText(this@AddHabitActivity, "Сохранено!", Toast.LENGTH_SHORT).show()
                    finish()
                }
            } else {
                Toast.makeText(this, "Заголовок не может быть пустым!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}