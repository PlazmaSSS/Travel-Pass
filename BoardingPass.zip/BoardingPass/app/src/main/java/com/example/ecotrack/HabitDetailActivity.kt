package com.example.ecotrack

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class HabitDetailActivity : AppCompatActivity() {

    private lateinit var habitViewModel: HabitViewModel
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_habit_detail)

        db = AppDatabase.getDatabase(this)

        val dao = db.habitDao()
        val repository = HabitRepository(dao)
        val factory = HabitViewModelFactory(repository)
        habitViewModel = ViewModelProvider(this, factory).get(HabitViewModel::class.java)

        val habitId = intent.getLongExtra("HABIT_ID", -1L)

        if (habitId != -1L) {
            loadHabitDetails(habitId)
        }

        val btnDelete = findViewById<Button>(R.id.btnDelete)
        btnDelete.setOnClickListener {

            lifecycleScope.launch {
                val habit = db.habitDao().getHabitById(habitId)
                if (habit != null) {
                    habitViewModel.delete(habit)
                    finish()
                }
            }
        }
    }

    private fun loadHabitDetails(id: Long) {

        lifecycleScope.launch {
            val habit = db.habitDao().getHabitById(id)
            if (habit != null) {
                findViewById<TextView>(R.id.tvDetailTitle).text = habit.title
                findViewById<TextView>(R.id.tvDetailDescription).text = habit.description
            }
        }
    }
}