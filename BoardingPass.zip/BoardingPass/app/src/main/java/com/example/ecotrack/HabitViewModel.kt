package com.example.ecotrack

import androidx.lifecycle.*
import kotlinx.coroutines.launch

class HabitViewModel(private val repository: HabitRepository) : ViewModel() {

    val allHabits: LiveData<List<Habit>> = repository.allHabits.asLiveData()

    fun delete(habit: Habit) = viewModelScope.launch {
        repository.delete(habit)
    }

    fun insert(habit: Habit) = viewModelScope.launch {
        repository.insert(habit)
    }
}

class HabitViewModelFactory(private val repository: HabitRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(HabitViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return HabitViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}